src_dir: ./src/
output_dir: ./docs/
title: EXCEED-DM
project: EXCEED-DM
project_github: https://github.com/tanner-trickle/EXCEED-DM
summary: EXtended Calculation of Electronic Excitations for Direct detection of Dark Matter.
author: Tanner Trickle
github: https://github.com/tanner-trickle
date: 05/3/2021
email: ttrickle17@gmail.com
source: false
version: 0.1.0
print_creation_date: true
exclude: fftw3.f90
         special_functions.f90
