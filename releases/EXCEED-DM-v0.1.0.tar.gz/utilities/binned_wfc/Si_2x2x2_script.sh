#!/bin/bash

./binned_wfc \
    100 \
    100 \
    40.888 \
    "/mnt/c/Users/Tanner/Desktop/dm-electron/examples/Si/dft/Si_2x2x2_AE.hdf5" \
    "/mnt/c/Users/Tanner/Desktop/dm-electron/examples/Si/core/Si_core_elec_config_RHF.hdf5" \
    "/mnt/c/Users/Tanner/Desktop/dm-electron/examples/RHF_wf_data.hdf5" \
    "/mnt/c/Users/Tanner/Desktop/dm-electron/utilities/binned_wfc/binned_wfc_Si_2x2x2.hdf5" \
/
